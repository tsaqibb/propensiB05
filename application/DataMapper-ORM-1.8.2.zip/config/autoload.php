<?php
# Load the Datamapper library when the spark is loaded
$autoload['libraries'] = array('database', 'datamapper');

